Les commandes à lancer pour éxecuter le programme sont :
    gcc main.c meshing.c
    ./a.out


Il est possible de tester la fonction lecture d'un fichier de maillage depuis le main, en changeant juste le nom du fichier txt 
(pour l'instant c'est le car3x3t_3).
